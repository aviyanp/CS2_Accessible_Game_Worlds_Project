class basicHouseNotMainBlock {
    constructor(positionx, positiony) {
        this.x = positionx;
        this.y = positiony;
        this.type = 3;
        this.hover = 0;
        this.image = house;
    }
}