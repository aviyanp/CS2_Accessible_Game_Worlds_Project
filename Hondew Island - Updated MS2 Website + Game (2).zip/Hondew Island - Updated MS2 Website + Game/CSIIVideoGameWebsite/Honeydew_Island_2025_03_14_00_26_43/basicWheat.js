class basicWheat {
    constructor(x, y) {
        this.crop = "wheat";
        this.cost = random(6, 12);
        this.sellValue = random(8, 15);
    }
}